package com.ways2u.android.test;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PointF;
import android.media.FaceDetector;
import android.os.Bundle;
import android.widget.ImageView;

public class MainActivity extends Activity {
	private ImageView mImageView;    // ͼƬ��ʾ�ؼ�
    private Bitmap mBitmap;
    private float mScale = 1F;

    @Override
    public void onCreate(Bundle savedInstanceState) {
             super.onCreate(savedInstanceState);
             setContentView(R.layout.main);
             mImageView = (ImageView) this.findViewById(R.id.image);
             detect();      // ʶ����
    }

    private void handleFace(FaceDetector.Face f) {        // ��ͼƬ�϶�ÿ�������д���
             PointF midPoint = new PointF();
             int r = ((int) (f.eyesDistance() * mScale * 1.5));         // ȡ�۾������
             f.getMidPoint(midPoint);       // ȡ�����е�
             midPoint.x *= mScale;
             midPoint.y *= mScale;
             Canvas c = new Canvas(mBitmap);
             Paint p = new Paint();
             p.setAntiAlias(true);
             p.setAlpha(0x80);
             c.drawCircle(midPoint.x, midPoint.y, r, p);       // �ð�͸�������������;
             mImageView.setImageBitmap(mBitmap);          // ��ʾͼƬ
    }

    private void detect() {
             Matrix matrix = new Matrix();
             FaceDetector.Face[] mFaces = new FaceDetector.Face[3];         // �������ʶ��������
             int mNumFaces = 0;

             mBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.qq);     // ȡԭʼͼ
             if (mBitmap == null) {
                      return;
             }
             if (mBitmap.getWidth() > 256) {
                      mScale = 256.0F / mBitmap.getWidth();
             }
             matrix.setScale(mScale, mScale);
             Bitmap faceBitmap = Bitmap.createBitmap(mBitmap, 0, 0, mBitmap
                                .getWidth(), mBitmap.getHeight(), matrix, true);        // �������ź����ͼ

             mScale = 1.0F / mScale;
             if (faceBitmap != null) {
                      FaceDetector detector = new FaceDetector(faceBitmap.getWidth(),
                                         faceBitmap.getHeight(), mFaces.length); // ����ʶ����
                      mNumFaces = detector.findFaces(faceBitmap, mFaces);    // ʶ��
                      if (mNumFaces > 0) {
                                for (int i = 0; i < mNumFaces; i++) {
                                         handleFace(mFaces[i]);        // ���ú���������������д���
                                }
                      }
             }
    }
}
